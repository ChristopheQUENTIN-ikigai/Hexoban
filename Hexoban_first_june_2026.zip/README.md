# Hexoban
Adaptation of Sokoban game with hex cells grid and other extra features, try to train AI to solve it.


Hexoganal grid version of Sokoban with some features such as laser, crumble tiles, teleportation ...  Work in progress 

Recently addressed:
===================
- Textures: the PNG/JPG art in `./assets/textures` is now loaded and drawn
  via a SpriteList-batched renderer (`src/renderer.py`); tiles that have no
  art on disk (slabs, colored targets/boxes, crumble, radioactive) are
  generated procedurally. Rendering the board is now a handful of batched GL
  calls per frame instead of hundreds of immediate-mode primitive calls, and
  the per-cell work happens only when the board changes, not every frame.
  (The data layer is covered by headless tests in `tests/test_renderer.py`;
  the final on-screen look should still be eyeballed by running the game.)

- Levels: the 30-level campaign was rebuilt with a measured, monotonic
  difficulty ramp (Tutorial -> Easy -> Medium -> Hard -> Extreme, plus a
  mechanics-showcase section). A byte-identical duplicate level was removed
  and the ceiling raised substantially. Every level is verified solvable and
  tier-rated by `tools/difficulty.py` / `tools/verify_level.py`.

- Solver/perf: BFS/A*/macro solvers rewritten with parent-pointer path
  reconstruction, precomputed neighbour/walkable tables and a deadlock cache;
  the engine gained a slab-position cache. The engine-driven extended search
  (lasers/portals/colored boxes) drops a redundant snapshot per direction.
  Solutions are unchanged and the benchmark set runs ~2x faster. Per-frame
  disk reads in the play and resolver views were cached, and the editor's
  Solve/Analyze now run off the UI thread.

- CBRN player: the suited-player sprite is now generated procedurally
  (a readable hazmat figure with visor + radiation badge) instead of the old
  poor PNG.

- Radioactive gameplay: boxes can now be pushed onto radioactive tiles (the
  radiation is a hazard for the player, who still needs the CBRN suit to step
  there, not for inert crates). Pushing a box further across radioactive
  ground requires the suit. Covered by tests in `tests/test_engine.py`.

- Replay: fixed — `ReplayView` had no `on_update`, so the board never
  advanced past the first frame. It now plays back on a timer with
  pause (Space), restart (R) and speed (Up/Down) controls, and renders
  dynamic tiles/CBRN state correctly. Covered by `tests/test_replay.py`.

- Headless solving: `tools/solve.py` solves any built-in level (by number or
  name) or an external level file from the command line, with optional
  difficulty tiering and solution saving — no GUI required.

TODO / future ideas:
====================
- Native speedups: a Rust/PyO3 port of the search remains a possible future
  optimization (not bundled — it would require a Rust toolchain to build).
  The remaining hot cost is the engine's own per-move undo snapshot.


<img width="1631" height="948" alt="map_custom1" src="https://github.com/user-attachments/assets/a2c317c1-7430-4c14-8c5c-e26deba50900" />
