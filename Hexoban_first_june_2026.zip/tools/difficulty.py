#!/usr/bin/env python3
"""Difficulty meter for Hexoban levels.

Runs an OPTIMAL breadth-first search over engine states and reports the
number of states explored before the first solution is found. This is the
metric the game itself uses (src/solutions.classify_difficulty): BFS state
count is the standard Sokoban difficulty measure because it captures the
true branching complexity of the puzzle, not just the path length.

Because the search is driven by engine.move(), it works uniformly for
classic levels and for extended levels (lasers, keys, gates, portals,
colored boxes, crumble/radioactive/CBRN).

Usage:
    python tools/difficulty.py                 # all built-ins
    python tools/difficulty.py 5 21            # built-ins 5 and 21 (1-indexed)
    python tools/difficulty.py levels/x.json   # a level file
"""
import os
import sys
import time
from collections import deque

_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _root)
os.chdir(_root)

from src.engine import HexobanEngine
from src.levels import BUILTIN_LEVELS, load_level_file
from src.solutions import classify_difficulty

ALL_DIRS = ["TOP_LEFT", "TOP_RIGHT", "LEFT", "RIGHT", "BOTTOM_LEFT", "BOTTOM_RIGHT"]


def _state_key(s):
    return (s.player_r, s.player_c, s.boxes, s.held_keys, s.opened_gates,
            s.collected_keys, s.box_colors, s.switch_on, s.has_cbrn,
            s.collapsed_tiles, s.collected_cbrn)


def measure(lines, max_states=2_000_000, time_limit=60.0):
    """Return dict with optimal-BFS difficulty stats for a level.

    keys: solvable(bool), optimal_moves(int|None), states(int),
          seconds(float), exhausted(bool), tier(str)
    """
    eng = HexobanEngine()
    eng.load_from_lines(lines)
    if eng.is_solved():
        return dict(solvable=True, optimal_moves=0, states=0, seconds=0.0,
                    exhausted=False, tier=classify_difficulty(0, len(eng.boxes), 0))

    init = eng._snapshot()
    visited = {_state_key(init)}
    q = deque([(init, 0)])
    states = 0
    t0 = time.time()
    solved_len = None
    exhausted = True

    while q:
        if states >= max_states or (time.time() - t0) > time_limit:
            exhausted = False
            break
        state, depth = q.popleft()
        states += 1
        eng._restore(state)
        for d in ALL_DIRS:
            before = eng._snapshot()
            if not eng.move(d):
                continue
            ns = eng._snapshot()
            k = _state_key(ns)
            solved = eng.is_solved()
            eng._restore(before)
            eng.history.clear()
            eng.future.clear()
            if k in visited:
                continue
            if solved:
                solved_len = depth + 1
                q.clear()
                break
            visited.add(k)
            q.append((ns, depth + 1))

    secs = time.time() - t0
    nb = len(eng.boxes)
    if solved_len is not None:
        tier = classify_difficulty(states, nb, solved_len)
        return dict(solvable=True, optimal_moves=solved_len, states=states,
                    seconds=secs, exhausted=False, tier=tier)
    return dict(solvable=False, optimal_moves=None, states=states,
                seconds=secs, exhausted=exhausted,
                tier="UNSOLVED" if exhausted else "TIMEOUT/BUDGET")


def _targets(argv):
    if not argv:
        return [(lv["name"], lv["data"]) for lv in BUILTIN_LEVELS]
    out = []
    for a in argv:
        if a.isdigit():
            i = int(a) - 1
            if 0 <= i < len(BUILTIN_LEVELS):
                out.append((BUILTIN_LEVELS[i]["name"], BUILTIN_LEVELS[i]["data"]))
        else:
            d = load_level_file(a)
            if d:
                out.append((d.get("name", a), d["data"]))
    return out


def main(argv):
    rows = []
    print(f"{'Level':<30s}{'Box':>4s}{'Opt.moves':>10s}{'BFS states':>12s}{'Time':>8s}  Tier")
    print("-" * 80)
    for name, lines in _targets(argv):
        r = measure(lines)
        rows.append((name, r))
        mv = r["optimal_moves"] if r["optimal_moves"] is not None else "-"
        eng = HexobanEngine(); eng.load_from_lines(lines)
        print(f"{name:<30s}{len(eng.boxes):>4d}{str(mv):>10s}"
              f"{r['states']:>12,d}{r['seconds']:>7.2f}s  {r['tier']}")
    print("-" * 80)
    solved = sum(1 for _, r in rows if r["solvable"])
    print(f"{solved}/{len(rows)} solvable within budget")
    return rows


if __name__ == "__main__":
    main(sys.argv[1:])
