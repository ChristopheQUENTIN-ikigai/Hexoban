#!/usr/bin/env python3
"""Verify a candidate Hexoban level: structural validity + difficulty.

For each level it reports:
  - players / boxes / targets counts and basic structural sanity
  - optimal-BFS difficulty (states explored -> tier) within a budget
  - if BFS exceeds budget, whether the game's own solve() can still solve it
    (macro-solver fallback) — a level that BFS can't crack but solve() can is
    legitimately Hard/Extreme.
"""
import os, sys, io
from collections import deque

_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _root); os.chdir(_root)

from src.engine import HexobanEngine
from src.levels import parse_level, CHAR_MAP
from src.solutions import classify_difficulty
from src.resolver import solve

ALL_DIRS = ["TOP_LEFT", "TOP_RIGHT", "LEFT", "RIGHT", "BOTTOM_LEFT", "BOTTOM_RIGHT"]


def _key(s):
    return (s.player_r, s.player_c, s.boxes, s.held_keys, s.opened_gates,
            s.collected_keys, s.box_colors, s.switch_on, s.has_cbrn,
            s.collapsed_tiles, s.collected_cbrn)


def bfs_difficulty(lines, max_states=300_000, time_limit=30.0):
    import time
    eng = HexobanEngine(); eng.load_from_lines(lines)
    if eng.is_solved():
        return True, 0, 0
    init = eng._snapshot(); seen = {_key(init)}; q = deque([(init, 0)])
    states = 0; t0 = time.time()
    while q:
        if states >= max_states or time.time() - t0 > time_limit:
            return None, states, None        # budget/time exceeded
        st, depth = q.popleft(); states += 1
        eng._restore(st)
        for d in ALL_DIRS:
            before = eng._snapshot()
            if not eng.move(d):
                continue
            ns = eng._snapshot(); k = _key(ns); solved = eng.is_solved()
            eng._restore(before); eng.history.clear(); eng.future.clear()
            if k in seen:
                continue
            if solved:
                return True, states, depth + 1
            seen.add(k); q.append((ns, depth + 1))
    return False, states, None               # exhausted, unsolvable


def structural(lines):
    grid, pr, pc = parse_level(lines)
    box_chars = set("$*1234MNOV")
    tgt_chars = set(".+*mnovMNOV")
    players = boxes = targets = 0
    for r, line in enumerate(lines):
        content = line[1:] if (r % 2 == 1 and line.startswith(' ')) else line
        cells = content[::2]
        players += sum(1 for ch in cells if ch in ("@", "+"))
        boxes += sum(1 for ch in cells if ch in box_chars)
        targets += sum(1 for ch in cells if ch in tgt_chars)
    return players, boxes, targets


def verify(name, lines, want_tier=None, budget=300_000):
    players, boxes, targets = structural(lines)
    flags = []
    if players != 1:
        flags.append(f"PLAYERS={players}")
    if boxes != targets:
        flags.append(f"box/target mismatch {boxes}/{targets}")
    solvable, states, moves = bfs_difficulty(lines, max_states=budget)
    if solvable is True:
        tier = classify_difficulty(states, boxes, moves or 0)
        verdict = f"SOLVABLE  {states:>7,} states  {moves:>3} moves  [{tier}]"
    elif solvable is False:
        verdict = f"UNSOLVABLE (exhausted {states:,} states)"
        flags.append("UNSOLVABLE")
        tier = "UNSOLVABLE"
    else:
        # BFS budget exceeded — fall back to the game's solver to prove solvable
        _o = sys.stdout; sys.stdout = io.StringIO()
        eng = HexobanEngine(); eng.load_from_lines(lines)
        sol = solve(eng); sys.stdout = _o
        if sol:
            eng2 = HexobanEngine(); eng2.load_from_lines(lines)
            ok = all(eng2.move(d) for d in sol) and eng2.is_solved()
            tier = "Extreme(BFS>budget)"
            verdict = (f"SOLVABLE via solve() {len(sol)}m "
                       f"(BFS>{budget:,} states)  [{tier}]"
                       + ("" if ok else "  !!REPLAY FAILED"))
            if not ok:
                flags.append("REPLAY FAILED")
        else:
            tier = "UNKNOWN"
            verdict = f"solve() FAILED and BFS>{budget:,} — UNVERIFIED"
            flags.append("UNVERIFIED")
    flag_s = ("  ⚠ " + ", ".join(flags)) if flags else ""
    print(f"{name:<26} b={boxes} {verdict}{flag_s}")
    return tier, flags


if __name__ == "__main__":
    # quick self-test on a couple built-ins
    from src.levels import BUILTIN_LEVELS
    for i in (1, 16, 20):
        lv = BUILTIN_LEVELS[i - 1]
        verify(lv["name"], lv["data"])
