#!/usr/bin/env python3
"""Headless command-line solver for Hexoban levels.

Solve any built-in level (by number or name) or an external level file from
the terminal — no GUI, no GL context. Useful for batch checking, CI, or
generating reference solutions.

Examples
--------
    python tools/solve.py --list                 # list built-in levels
    python tools/solve.py 28                      # solve built-in #28
    python tools/solve.py "Color Match"           # solve by name (substring)
    python tools/solve.py my_level.txt            # solve an XSB/text level file
    python tools/solve.py 21 --tier               # also report difficulty tier
    python tools/solve.py 21 --save               # persist the solution
    python tools/solve.py 28 --moves              # print the full move list
"""
import argparse
import io
import os
import sys
import time

_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, _root)
os.chdir(_root)

from src.engine import HexobanEngine
from src.levels import BUILTIN_LEVELS, parse_level  # noqa: F401
from src.resolver import solve


def _resolve_level(spec: str):
    """Return (name, lines) for a level spec: an index, a name substring, or
    a path to a level file."""
    # explicit file path
    if os.path.isfile(spec):
        with open(spec) as f:
            lines = [ln.rstrip("\n") for ln in f if ln.strip("\n")]
        return os.path.basename(spec), lines
    # 1-based index
    if spec.isdigit():
        i = int(spec)
        if 1 <= i <= len(BUILTIN_LEVELS):
            lv = BUILTIN_LEVELS[i - 1]
            return lv["name"], lv["data"]
        raise SystemExit(f"index {i} out of range (1..{len(BUILTIN_LEVELS)})")
    # name substring (case-insensitive)
    matches = [lv for lv in BUILTIN_LEVELS if spec.lower() in lv["name"].lower()]
    if not matches:
        raise SystemExit(f"no built-in level matches {spec!r} (try --list)")
    if len(matches) > 1:
        names = ", ".join(m["name"] for m in matches)
        raise SystemExit(f"{spec!r} is ambiguous: {names}")
    return matches[0]["name"], matches[0]["data"]


def _count_pushes(lines, moves):
    eng = HexobanEngine(); eng.load_from_lines(lines)
    for d in moves:
        eng.move(d)
    return eng.pushes, eng.is_solved()


def _tier(lines, budget=300_000):
    """Optimal-BFS difficulty tier (may be slow / exceed budget)."""
    from collections import deque
    from src.solutions import classify_difficulty
    eng = HexobanEngine(); eng.load_from_lines(lines)

    def key(s):
        return (s.player_r, s.player_c, s.boxes, s.held_keys, s.opened_gates,
                s.collected_keys, s.box_colors, s.switch_on, s.has_cbrn,
                s.collapsed_tiles, s.collected_cbrn)

    if eng.is_solved():
        return "Tutorial", 0
    init = eng._snapshot(); seen = {key(init)}; q = deque([(init, 0)]); n = 0
    dirs = ["TOP_LEFT", "TOP_RIGHT", "LEFT", "RIGHT", "BOTTOM_LEFT", "BOTTOM_RIGHT"]
    nbox = len(eng.boxes)
    while q and n < budget:
        st, depth = q.popleft(); n += 1
        eng._restore(st)
        for d in dirs:
            if not eng.move(d):
                continue
            ns = eng._snapshot(); k = key(ns); solved = eng.is_solved()
            eng._restore(st); eng.history.clear(); eng.future.clear()
            if k in seen:
                continue
            if solved:
                return classify_difficulty(n, nbox, depth + 1), n
            seen.add(k); q.append((ns, depth + 1))
    return f"Extreme(BFS>{budget:,})", n


def main(argv=None):
    ap = argparse.ArgumentParser(description="Headless Hexoban solver")
    ap.add_argument("level", nargs="?", help="level number, name substring, or file path")
    ap.add_argument("--list", action="store_true", help="list built-in levels and exit")
    ap.add_argument("--moves", action="store_true", help="print the full move list")
    ap.add_argument("--tier", action="store_true", help="also compute the difficulty tier (can be slow)")
    ap.add_argument("--save", action="store_true", help="persist the solution via the solutions store")
    ap.add_argument("--quiet", action="store_true", help="suppress solver progress logging")
    args = ap.parse_args(argv)

    if args.list:
        for i, lv in enumerate(BUILTIN_LEVELS, 1):
            print(f"{i:>2}. {lv['name']}")
        return 0
    if not args.level:
        ap.error("a level is required (or use --list)")

    name, lines = _resolve_level(args.level)
    eng = HexobanEngine(); eng.load_from_lines(lines)
    print(f"Solving: {name}  ({eng.rows}x{eng.cols}, {len(eng.boxes)} boxes)")

    t0 = time.time()
    if args.quiet:
        _o = sys.stdout; sys.stdout = io.StringIO()
        sol = solve(eng); sys.stdout = _o
    else:
        sol = solve(eng)
    dt = time.time() - t0

    if not sol:
        print(f"  UNSOLVED (no solution found in {dt:.2f}s)")
        return 1
    pushes, ok = _count_pushes(lines, sol)
    status = "verified" if ok else "!! REPLAY FAILED"
    print(f"  SOLVED in {dt:.2f}s: {len(sol)} moves, {pushes} pushes [{status}]")
    if args.tier:
        tier, states = _tier(lines)
        print(f"  difficulty: {tier} ({states:,} BFS states explored)")
    if args.moves:
        print("  moves: " + " ".join(sol))
    if args.save:
        from src.solutions import save_solution
        save_solution(name, lines, sol, pushes, is_best=True)
        print("  solution saved.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
