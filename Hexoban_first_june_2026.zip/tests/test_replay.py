"""Regression test for the Replay view.

The replay used to appear broken because ReplayView had no on_update method,
so the board never advanced past the first frame. These tests drive on_update
directly (no GL window needed) and assert the replay steps forward, reaches
the solved state, and honours pause.
"""
import io
import sys
import pytest

from src.engine import HexobanEngine
from src.levels import BUILTIN_LEVELS
from src.resolver import solve

game = pytest.importorskip("src.game")
ReplayView = game.ReplayView


def _solution(level_name):
    lv = next(l for l in BUILTIN_LEVELS if l["name"] == level_name)
    eng = HexobanEngine(); eng.load_from_lines(lv["data"])
    _o = sys.stdout; sys.stdout = io.StringIO()
    moves = solve(eng)
    sys.stdout = _o
    return lv["data"], moves


def _make_replay(level_data, moves, paused=False, speed=0.30):
    rv = ReplayView.__new__(ReplayView)          # skip arcade window init
    rv.replay_engine = HexobanEngine()
    rv.replay_engine.load_from_lines(level_data)
    rv.replay_moves = moves
    rv.replay_idx = 0
    rv.replay_timer = 0.0
    rv.replay_speed = speed
    rv.replay_paused = paused
    rv._replay_lines = level_data
    return rv


def test_replay_advances_to_solved():
    data, moves = _solution("9. The Nook")
    rv = _make_replay(data, moves)
    assert rv.replay_idx == 0 and not rv.replay_engine.is_solved()
    for _ in range(len(moves) + 3):
        rv.on_update(rv.replay_speed)        # each tick steps one move
    assert rv.replay_idx == len(moves)
    assert rv.replay_engine.is_solved()


def test_replay_pause_halts_progress():
    data, moves = _solution("9. The Nook")
    rv = _make_replay(data, moves, paused=True)
    for _ in range(5):
        rv.on_update(rv.replay_speed)
    assert rv.replay_idx == 0


def test_replay_respects_timer_threshold():
    """Sub-threshold dt accumulates without stepping; crossing it steps once."""
    data, moves = _solution("9. The Nook")
    rv = _make_replay(data, moves, speed=0.30)
    rv.on_update(0.10)
    assert rv.replay_idx == 0          # not enough elapsed
    rv.on_update(0.10)
    assert rv.replay_idx == 0
    rv.on_update(0.10)                  # now total >= 0.30
    assert rv.replay_idx == 1
