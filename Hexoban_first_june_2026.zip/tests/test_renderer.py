"""Headless tests for the texture/SpriteList renderer (src/renderer.py).

These verify everything that does NOT require an open GL window:
  * the real PNG/JPG art is actually loaded (the original bug was that it
    was generated from primitives instead),
  * tiles with no art on disk are generated procedurally,
  * the tile/state -> texture mapping is correct,
  * the board partitions into exactly one sprite per non-void cell,
  * sprite positions match the view's cell_xy,
  * boxes and the player follow the engine after sync().

Only the final SpriteList.draw() needs a real window, so it is not covered
here; it is exercised by running the game.
"""
import math
import pytest

from src.engine import HexobanEngine
from src.levels import (BUILTIN_LEVELS, EMPTY, slab_id, laser_id, key_id,
                        gate_id, PORTAL_IN, PORTAL_OUT, SWITCH, CRUMBLE,
                        RADIOACTIVE, CBRN_ITEM)

renderer = pytest.importorskip("src.renderer")
TileTextures = renderer.TileTextures
BoardRenderer = renderer.BoardRenderer


def _cell_xy_factory(hex_size=40.0, ox=100.0, oy=600.0):
    def cell_xy(r, c):
        w = math.sqrt(3) * hex_size
        x = ox + c * w + (w / 2 if r % 2 else 0)
        y = oy - r * 1.5 * hex_size
        return x, y
    return cell_xy


@pytest.fixture(scope="module")
def tex():
    return TileTextures()


def test_core_art_loaded_from_disk(tex):
    """The headline fix: the main tiles use real PNG art, not procedural."""
    for must in ["wall", "floor", "target", "box", "box_on_target",
                 "player", "player_on_target"]:
        assert must in tex.loaded_from_disk, f"{must} should load from PNG"
    # and several mechanic tiles too
    for must in ["laser0_on", "gate0_shut", "switch_on", "key0",
                 "portal_in_on", "cbrn_item"]:
        assert must in tex.loaded_from_disk


def test_missing_tiles_are_generated(tex):
    """Tiles with no art on disk must be generated procedurally."""
    for k in ["slab0_off", "slab0_on", "ctarget0", "cbox0_off", "cbox0_on",
              "crumble", "radioactive"]:
        assert k in tex.generated
        assert tex.get(k) is not None


def test_every_known_key_resolves(tex):
    """Every key produced by tile_key/box_key/player_key has a texture."""
    keys = set()
    for tid in [1, 2, 3] + [slab_id(g) for g in range(4)] \
            + [laser_id(g) for g in range(4)] + [key_id(c) for c in range(4)] \
            + [gate_id(c) for c in range(4)] \
            + [PORTAL_IN, PORTAL_OUT, SWITCH, CRUMBLE, RADIOACTIVE, CBRN_ITEM]:
        for la in (True, False):
            for st in (True, False):
                k = tex.tile_key(tid, laser_active=la, gate_opened=st,
                                 slab_pressed=st, switch_on=st,
                                 portal_active=st, collected=False)
                if k:
                    keys.add(k)
    for ot in (True, False):
        keys.add(tex.box_key(ot, -1))
        for c in range(4):
            keys.add(tex.box_key(ot, c))
        keys.add(tex.player_key(False, ot))
        keys.add(tex.player_key(True, ot))
    for k in keys:
        assert tex.get(k) is not None, f"no texture for key {k!r}"


def test_empty_tile_has_no_texture(tex):
    assert tex.tile_key(EMPTY) is None


def test_collected_key_renders_as_floor(tex):
    assert tex.tile_key(key_id(0), collected=True) == "floor"
    assert tex.tile_key(CBRN_ITEM, collected=True) == "floor"


def _build_for_level(tex, name):
    lv = next(l for l in BUILTIN_LEVELS if l["name"] == name)
    eng = HexobanEngine(); eng.load_from_lines(lv["data"])
    rend = BoardRenderer(tex)
    rend.build(eng, _cell_xy_factory(), 40.0)
    return eng, rend


@pytest.mark.parametrize("name", ["26. Laser Lock", "28. Color Match",
                                   "30. The Vault", "20. Pinwheel"])
def test_one_sprite_per_cell(tex, name):
    eng, rend = _build_for_level(tex, name)
    non_void = sum(1 for r in range(eng.rows) for c in range(eng.cols)
                   if eng.grid[r][c] != EMPTY)
    assert len(rend.static_list) + len(rend.dynamic_list) == non_void
    assert len(rend.box_list) == len(eng.boxes)
    assert len(rend.player_list) == 1


def test_sprite_positions_match_cell_xy(tex):
    eng, rend = _build_for_level(tex, "26. Laser Lock")
    cell_xy = _cell_xy_factory()
    for (r, c), spr in rend._dynamic_cells.items():
        x, y = cell_xy(r, c)
        assert abs(spr.center_x - x) < 1e-6
        assert abs(spr.center_y - y) < 1e-6


def test_player_and_boxes_follow_engine_after_sync(tex):
    eng, rend = _build_for_level(tex, "26. Laser Lock")
    cell_xy = _cell_xy_factory()
    before = (rend._player_sprite.center_x, rend._player_sprite.center_y)
    moved = None
    for d in ["RIGHT", "LEFT", "TOP_LEFT", "TOP_RIGHT",
              "BOTTOM_LEFT", "BOTTOM_RIGHT"]:
        if eng.move(d):
            moved = d
            break
    assert moved is not None
    rend.sync(eng)
    exp = cell_xy(eng.player_r, eng.player_c)
    assert abs(rend._player_sprite.center_x - exp[0]) < 1e-6
    assert abs(rend._player_sprite.center_y - exp[1]) < 1e-6
    assert (rend._player_sprite.center_x, rend._player_sprite.center_y) != before
    assert len(rend.box_list) == len(eng.boxes)


def test_dynamic_tile_texture_changes_with_state(tex):
    """A laser tile's texture must differ between armed and disarmed."""
    eng, rend = _build_for_level(tex, "26. Laser Lock")
    # find a laser cell
    from src.levels import is_laser
    laser_cell = next(((r, c) for r in range(eng.rows) for c in range(eng.cols)
                       if is_laser(eng.grid[r][c])), None)
    assert laser_cell is not None
    armed_tex = rend._dynamic_cells[laser_cell].texture
    # disarm by checking the "off" variant differs from current armed art
    from src.levels import laser_group
    g = laser_group(eng.grid[laser_cell[0]][laser_cell[1]])
    assert tex.get(f"laser{g}_on") is not tex.get(f"laser{g}_off")
