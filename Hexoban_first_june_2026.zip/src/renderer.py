"""Texture-backed, SpriteList-batched board renderer for Hexoban.

Why this module exists
----------------------
The original GameView.on_draw iterated every cell of the grid on *every
frame* and issued immediate-mode ``arcade.draw_*`` primitive calls (each a
separate GL draw). For a typical board that is hundreds of GL calls per
frame, and the texture PNGs shipped in ``assets/textures`` were never
actually loaded — the art was redrawn from primitives instead.

This renderer fixes both problems at once:

* **Textures (loads the real art).** :class:`TileTextures` loads the PNG/JPG
  assets via ``arcade.load_texture`` and *procedurally generates only the
  tiles that have no art on disk* (slabs, colored targets, crumble,
  radioactive floor, colored boxes) as ``arcade.Texture`` objects built from
  Pillow images. Every tile/state combination resolves to a cached texture.

* **SpriteList batching (one GL call per layer).** :class:`BoardRenderer`
  builds a *static* SpriteList once per layout (walls, floors, targets — the
  bulk of the cells, whose appearance never changes) plus small dynamic
  SpriteLists for state-changing tiles, the boxes and the player. Drawing the
  whole board is then ~4 batched GL calls instead of hundreds, and the
  per-cell Python work happens only when the board actually changes
  (:meth:`BoardRenderer.sync`, called after a move) rather than every frame.

The module is import-safe and unit-testable headlessly: ``arcade.load_texture``
and ``arcade.Texture(PIL_image)`` and ``SpriteList`` construction all work
without an open GL window, so sprite counts, positions and the
tile/state -> texture mapping can be verified in tests. Only the final
``SpriteList.draw()`` needs a real window.
"""
from __future__ import annotations

import math
from pathlib import Path
from typing import Callable, Optional

import arcade
from PIL import Image, ImageDraw

from src.levels import (
    EMPTY, WALL, FLOOR, TARGET,
    is_slab, is_laser, is_key, is_gate, is_portal_in, is_portal_out,
    is_switch, is_colored_target, is_crumble, is_radioactive, is_cbrn_item,
    slab_group, laser_group, key_color, gate_color, target_color,
)

TEX_DIR = Path("assets/textures")

# Resolution at which procedural tiles are rendered; sprites are scaled to the
# board's hex size at runtime, so this just sets crispness.
TEX_RES = 128

# ── palettes (kept in sync with the primitive drawers in game.py) ──
C_WALL = (100, 80, 60)
C_FLOOR = (200, 190, 170)
C_HEX_OUTLINE = (60, 55, 45)
LASER_GROUP_COLORS = [(80, 220, 255), (220, 80, 220), (230, 230, 60), (255, 140, 40)]
SLAB_GROUP_COLORS = [(40, 110, 130), (110, 40, 110), (120, 120, 35), (130, 70, 25)]
KEY_COLORS = [(230, 60, 60), (60, 200, 90), (70, 120, 230), (230, 200, 60)]
BOX_COLOR_PALETTE = [(220, 70, 70), (70, 200, 220), (130, 220, 70), (200, 100, 220)]
TARGET_COLOR_PALETTE = [(170, 40, 40), (40, 150, 170), (90, 170, 40), (150, 60, 170)]


# ═══════════════════════════════════════════════════════════════════
# Pillow helpers for procedural tiles
# ═══════════════════════════════════════════════════════════════════
def _hex_points(size: int, inset: float = 0.0):
    """Pointy-top hexagon vertices centred in a `size`x`size` image."""
    cx = cy = size / 2.0
    r = size / 2.0 - inset
    pts = []
    for k in range(6):
        ang = math.radians(60 * k - 90)  # pointy top
        pts.append((cx + r * math.cos(ang), cy + r * math.sin(ang)))
    return pts


def _hex_base(fill, outline=C_HEX_OUTLINE, lw=max(2, TEX_RES // 40)) -> Image.Image:
    """A filled pointy-top hex tile on a transparent background."""
    img = Image.new("RGBA", (TEX_RES, TEX_RES), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.polygon(_hex_points(TEX_RES, inset=lw), fill=tuple(fill) + (255,),
              outline=tuple(outline) + (255,))
    # second outline pass for a crisper edge at high res
    d.line(_hex_points(TEX_RES, inset=lw) + [_hex_points(TEX_RES, inset=lw)[0]],
           fill=tuple(outline) + (255,), width=lw)
    return img


def _to_texture(img: Image.Image, name: str) -> arcade.Texture:
    return arcade.Texture(img)


def _load(name: str) -> Optional[Image.Image]:
    """Load a PNG/JPG asset as RGBA, or None if absent."""
    p = TEX_DIR / name
    if not p.exists():
        return None
    im = Image.open(p).convert("RGBA")
    if im.size != (TEX_RES, TEX_RES):
        im = im.resize((TEX_RES, TEX_RES), Image.LANCZOS)
    return im


def _brightness(img: Image.Image, factor: float) -> Image.Image:
    """Multiply RGB by `factor` (keeps alpha). factor<1 darkens, >1 lightens."""
    r, g, b, a = img.split()
    lut = [min(255, int(i * factor)) for i in range(256)]
    return Image.merge("RGBA", (r.point(lut), g.point(lut), b.point(lut), a))


def _with_alpha(img: Image.Image, alpha: float) -> Image.Image:
    r, g, b, a = img.split()
    a = a.point(lambda i: int(i * alpha))
    return Image.merge("RGBA", (r, g, b, a))


def _tint(img: Image.Image, color) -> Image.Image:
    """Tint a (typically white/gray) icon toward `color`, preserving its alpha
    and luminance so PNG line-art keeps its shading."""
    r, g, b, a = img.split()
    gray = Image.merge("RGB", (r, g, b)).convert("L")
    cr = gray.point(lambda i: int(i * color[0] / 255))
    cg = gray.point(lambda i: int(i * color[1] / 255))
    cb = gray.point(lambda i: int(i * color[2] / 255))
    return Image.merge("RGBA", (cr, cg, cb, a))


def _composite_on_floor(icon: Image.Image, floor: Image.Image) -> Image.Image:
    """Lay an icon over a floor-hex base so the resulting tile is opaque."""
    base = floor.copy()
    base.alpha_composite(icon)
    return base


# ═══════════════════════════════════════════════════════════════════
# Texture manager
# ═══════════════════════════════════════════════════════════════════
class TileTextures:
    """Loads art for every tile/state and caches it as ``arcade.Texture``.

    PNGs/JPGs in assets/textures are used where present; tiles with no art are
    generated procedurally. Build once and share across views.
    """

    def __init__(self):
        self._cache: dict[str, arcade.Texture] = {}
        self.loaded_from_disk: set[str] = set()
        self.generated: set[str] = set()
        self._build()

    # ---- public lookup API ------------------------------------------------
    def get(self, key: str) -> Optional[arcade.Texture]:
        return self._cache.get(key)

    def tile_key(self, tid: int, *, laser_active=True, gate_opened=False,
                 slab_pressed=False, switch_on=False, portal_active=False,
                 collected=False) -> Optional[str]:
        """Logical texture key for a tile id in a given runtime state.

        Returns None for EMPTY/void cells (nothing drawn). Collected
        keys/CBRN items render as floor (matching the primitive renderer).
        """
        if tid == EMPTY:
            return None
        if tid == WALL:
            return "wall"
        if tid == FLOOR:
            return "floor"
        if tid == TARGET:
            return "target"
        if is_slab(tid):
            return f"slab{slab_group(tid)}_{'on' if slab_pressed else 'off'}"
        if is_laser(tid):
            return f"laser{laser_group(tid)}_{'on' if laser_active else 'off'}"
        if is_key(tid):
            return "floor" if collected else f"key{key_color(tid)}"
        if is_gate(tid):
            return f"gate{gate_color(tid)}_{'open' if gate_opened else 'shut'}"
        if is_portal_in(tid):
            return f"portal_in_{'on' if portal_active else 'off'}"
        if is_portal_out(tid):
            return f"portal_out_{'on' if portal_active else 'off'}"
        if is_switch(tid):
            return f"switch_{'on' if switch_on else 'off'}"
        if is_colored_target(tid):
            return f"ctarget{target_color(tid)}"
        if is_crumble(tid):
            return "crumble"
        if is_radioactive(tid):
            return "radioactive"
        if is_cbrn_item(tid):
            return "floor" if collected else "cbrn_item"
        return "floor"

    def box_key(self, on_target: bool, color: int = -1) -> str:
        if color < 0:
            return "box_on_target" if on_target else "box"
        return f"cbox{color}_{'on' if on_target else 'off'}"

    def player_key(self, has_cbrn: bool, on_target: bool) -> str:
        if has_cbrn:
            return "cbrn_player"
        return "player_on_target" if on_target else "player"

    def is_dynamic_tile(self, tid: int) -> bool:
        """True if the tile's *appearance* can change during play (so it must
        live in a dynamic, re-syncable sprite list rather than the static
        grid)."""
        return (is_laser(tid) or is_gate(tid) or is_slab(tid) or is_switch(tid)
                or is_portal_in(tid) or is_portal_out(tid) or is_key(tid)
                or is_cbrn_item(tid) or is_crumble(tid))

    # ---- construction -----------------------------------------------------
    def _put(self, key: str, img: Image.Image, *, from_disk=False):
        self._cache[key] = _to_texture(img, key)
        (self.loaded_from_disk if from_disk else self.generated).add(key)

    def _build(self):
        # Floor base reused for compositing icon tiles.
        floor_png = _load("floor.png")
        floor_img = floor_png if floor_png is not None else _hex_base(C_FLOOR)
        if floor_png is not None:
            self._put("floor", floor_png, from_disk=True)
        else:
            self._put("floor", floor_img)

        # --- plain tiles: prefer PNGs, else procedural ---
        for key, fname, fill in [("wall", "wall.png", C_WALL),
                                  ("target", "target.png", C_FLOOR)]:
            im = _load(fname)
            if im is not None:
                self._put(key, im, from_disk=True)
            else:
                base = _hex_base(fill)
                if key == "target":
                    d = ImageDraw.Draw(base)
                    rr = TEX_RES * 0.18
                    d.ellipse([TEX_RES/2-rr, TEX_RES/2-rr, TEX_RES/2+rr,
                               TEX_RES/2+rr], fill=(220, 60, 60, 255))
                self._put(key, base)

        # --- boxes & player: PNGs expected ---
        for key, fname in [("box", "box.png"), ("box_on_target", "box_on_target.png"),
                           ("player", "player.png"),
                           ("player_on_target", "player_on_target.png")]:
            im = _load(fname)
            if im is not None:
                self._put(key, im, from_disk=True)
            else:
                # fallback proxies so the game still renders if art is missing
                if "player" in key:
                    base = _hex_base(C_FLOOR)
                    d = ImageDraw.Draw(base); rr = TEX_RES*0.28
                    d.ellipse([TEX_RES/2-rr, TEX_RES/2-rr, TEX_RES/2+rr,
                               TEX_RES/2+rr], fill=(50, 100, 200, 255))
                    self._put(key, base)
                else:
                    self._put(key, self._proc_box(-1, key.endswith("target")))

        # --- CBRN-suited player: generated procedurally (the shipped
        # CBRN_player.png art was poor); a custom PNG could be re-enabled
        # here if desired. ---
        self._put("cbrn_player", self._proc_cbrn_player(floor_img))

        # --- CBRN item (suit) ---
        suit = _load("CBRN_suit.png")
        if suit is not None:
            self._put("cbrn_item", _composite_on_floor(suit, floor_img),
                      from_disk=True)
        else:
            self._put("cbrn_item", self._proc_radioactive((230, 230, 60)))

        # --- keys: tint a single key PNG per color, composite on floor ---
        key_png = _load("key.png")
        for c, col in enumerate(KEY_COLORS):
            if key_png is not None:
                icon = _tint(key_png, col)
                self._put(f"key{c}", _composite_on_floor(icon, floor_img),
                          from_disk=True)
            else:
                self._put(f"key{c}", self._proc_disc(col, floor_img))

        # --- switch on/off (PNG, brightness variants) ---
        sw = _load("switch.png")
        if sw is not None:
            self._put("switch_on", _composite_on_floor(_brightness(sw, 1.15),
                      floor_img), from_disk=True)
            self._put("switch_off", _composite_on_floor(_brightness(sw, 0.5),
                      floor_img), from_disk=True)
        else:
            self._put("switch_on", self._proc_disc((80, 230, 120), floor_img))
            self._put("switch_off", self._proc_disc((100, 100, 110), floor_img))

        # --- lasers on/off (JPG = active; darken for inactive) ---
        laser = _load("laser.jpg")
        for g in range(4):
            if laser is not None:
                on = _brightness(laser, 1.0)
                off = _brightness(laser, 0.35)
                self._put(f"laser{g}_on", on, from_disk=True)
                self._put(f"laser{g}_off", off, from_disk=True)
            else:
                self._put(f"laser{g}_on", self._proc_beam(LASER_GROUP_COLORS[g], True))
                self._put(f"laser{g}_off", self._proc_beam(LASER_GROUP_COLORS[g], False))

        # --- gates shut/open (JPG = shut; translucent for open) ---
        gate = _load("gate.jpg")
        for c in range(4):
            if gate is not None:
                self._put(f"gate{c}_shut", gate, from_disk=True)
                self._put(f"gate{c}_open",
                          _composite_on_floor(_with_alpha(gate, 0.30), floor_img),
                          from_disk=True)
            else:
                self._put(f"gate{c}_shut", self._proc_gate(KEY_COLORS[c], False))
                self._put(f"gate{c}_open", self._proc_gate(KEY_COLORS[c], True))

        # --- portals on/off (JPGs; darken for inactive) ---
        pin = _load("portal_blue.jpg")
        pout = _load("portal_orange.jpg")
        if pin is not None:
            self._put("portal_in_on", pin, from_disk=True)
            self._put("portal_in_off", _brightness(pin, 0.45), from_disk=True)
        else:
            self._put("portal_in_on", self._proc_portal((70, 140, 255), True))
            self._put("portal_in_off", self._proc_portal((40, 80, 140), False))
        if pout is not None:
            self._put("portal_out_on", pout, from_disk=True)
            self._put("portal_out_off", _brightness(pout, 0.45), from_disk=True)
        else:
            self._put("portal_out_on", self._proc_portal((255, 140, 40), True))
            self._put("portal_out_off", self._proc_portal((150, 90, 40), False))

        # --- procedural-only tiles (no art on disk) ---
        for g in range(4):
            self._put(f"slab{g}_off", self._proc_slab(SLAB_GROUP_COLORS[g]))
            self._put(f"slab{g}_on", self._proc_slab(LASER_GROUP_COLORS[g]))
        for c in range(4):
            self._put(f"ctarget{c}", self._proc_ctarget(c))
            self._put(f"cbox{c}_off", self._proc_box(c, False))
            self._put(f"cbox{c}_on", self._proc_box(c, True))
        self._put("crumble", self._proc_crumble())
        self._put("radioactive", self._proc_radioactive((90, 200, 90)))

    # ---- procedural tile painters ----------------------------------------
    def _proc_cbrn_player(self, floor_img):
        """A clean, readable hazmat-suited figure used for the player once the
        CBRN protective clothing is worn. Replaces the previous poor art with
        a self-contained procedural sprite: protective aura, yellow suit with
        a helmet + dark visor, and a radiation badge on the chest."""
        base = floor_img.copy()
        d = ImageDraw.Draw(base, "RGBA")
        H = TEX_RES
        cx = H / 2
        suit = (235, 205, 55, 255)
        suit_out = (150, 120, 20, 255)
        lw = max(2, H // 40)
        # protective green aura ring (reads as "shielded")
        d.ellipse([H*0.11, H*0.11, H*0.89, H*0.89],
                  outline=(90, 220, 120, 130), width=lw)
        # arms
        d.line([(H*0.35, H*0.56), (H*0.24, H*0.70)], fill=suit_out, width=max(4, H//14))
        d.line([(H*0.65, H*0.56), (H*0.76, H*0.70)], fill=suit_out, width=max(4, H//14))
        # suit body
        d.rounded_rectangle([H*0.32, H*0.46, H*0.68, H*0.86], radius=H*0.10,
                            fill=suit, outline=suit_out, width=lw)
        # boots
        d.rectangle([H*0.36, H*0.84, H*0.47, H*0.90], fill=suit_out)
        d.rectangle([H*0.53, H*0.84, H*0.64, H*0.90], fill=suit_out)
        # helmet
        hr = H * 0.16
        hy = H * 0.31
        d.ellipse([cx-hr, hy-hr, cx+hr, hy+hr], fill=(245, 225, 120, 255),
                  outline=suit_out, width=lw)
        # dark faceplate / visor in the lower half of the helmet
        d.ellipse([cx-hr*0.72, hy-hr*0.15, cx+hr*0.72, hy+hr*0.62],
                  fill=(45, 55, 78, 255))
        # small visor highlight
        d.ellipse([cx-hr*0.45, hy+hr*0.02, cx-hr*0.12, hy+hr*0.26],
                  fill=(120, 150, 190, 255))
        # radiation badge (trefoil) on the chest
        bx, by, br = cx, H*0.64, H*0.085
        for k in range(3):
            a0 = 90 + k*120 - 28
            a1 = 90 + k*120 + 28
            d.pieslice([bx-br, by-br, bx+br, by+br], a0, a1, fill=(30, 30, 30, 255))
        rr = br * 0.30
        d.ellipse([bx-rr, by-rr, bx+rr, by+rr], fill=(30, 30, 30, 255))
        return base

    def _proc_slab(self, col):
        base = _hex_base(col)
        d = ImageDraw.Draw(base)
        m = TEX_RES * 0.30
        d.rectangle([m, m, TEX_RES-m, TEX_RES-m],
                    outline=(255, 255, 255, 160), width=max(2, TEX_RES//40))
        return base

    def _proc_ctarget(self, c):
        base = _hex_base(C_FLOOR)
        d = ImageDraw.Draw(base)
        rr = TEX_RES * 0.22
        d.ellipse([TEX_RES/2-rr, TEX_RES/2-rr, TEX_RES/2+rr, TEX_RES/2+rr],
                  outline=tuple(TARGET_COLOR_PALETTE[c]) + (255,),
                  width=max(3, TEX_RES//22))
        rr2 = TEX_RES * 0.09
        d.ellipse([TEX_RES/2-rr2, TEX_RES/2-rr2, TEX_RES/2+rr2, TEX_RES/2+rr2],
                  fill=tuple(BOX_COLOR_PALETTE[c]) + (255,))
        return base

    def _proc_box(self, color, on_target):
        base = _hex_base(C_FLOOR)
        d = ImageDraw.Draw(base)
        col = BOX_COLOR_PALETTE[color] if color >= 0 else (180, 130, 50)
        out = (TARGET_COLOR_PALETTE[color] if (on_target and color >= 0)
               else (140, 100, 30))
        m = TEX_RES * 0.22
        rad = TEX_RES * 0.10
        d.rounded_rectangle([m, m, TEX_RES-m, TEX_RES-m], radius=rad,
                            fill=tuple(col) + (255,),
                            outline=tuple(out) + (255,), width=max(3, TEX_RES//26))
        return base

    def _proc_disc(self, col, floor_img):
        base = floor_img.copy()
        d = ImageDraw.Draw(base)
        rr = TEX_RES * 0.16
        d.ellipse([TEX_RES/2-rr, TEX_RES/2-rr, TEX_RES/2+rr, TEX_RES/2+rr],
                  fill=tuple(col) + (255,))
        return base

    def _proc_beam(self, col, active):
        base = _hex_base((30, 30, 38))
        d = ImageDraw.Draw(base)
        c = tuple(col) + (255,) if active else tuple(c // 3 for c in col) + (255,)
        d.line([(TEX_RES*0.15, TEX_RES/2), (TEX_RES*0.85, TEX_RES/2)],
               fill=c, width=max(3, TEX_RES//16))
        return base

    def _proc_gate(self, col, opened):
        base = _hex_base(C_FLOOR if opened else tuple(x//2 for x in col))
        if not opened:
            d = ImageDraw.Draw(base)
            for i in range(3):
                x = TEX_RES * (0.30 + i * 0.20)
                d.line([(x, TEX_RES*0.25), (x, TEX_RES*0.75)],
                       fill=(20, 20, 20, 255), width=max(2, TEX_RES//30))
        return base

    def _proc_portal(self, col, active):
        base = _hex_base((25, 25, 35))
        d = ImageDraw.Draw(base)
        c = tuple(col) + (255,)
        for k, rr in enumerate((0.30, 0.20, 0.10)):
            r = TEX_RES * rr
            d.ellipse([TEX_RES/2-r, TEX_RES/2-r, TEX_RES/2+r, TEX_RES/2+r],
                      outline=c, width=max(2, TEX_RES//40))
        return base

    def _proc_crumble(self):
        base = _hex_base((150, 140, 120))
        d = ImageDraw.Draw(base)
        d.line([(TEX_RES*0.3, TEX_RES*0.3), (TEX_RES*0.55, TEX_RES*0.6)],
               fill=(60, 50, 40, 255), width=max(2, TEX_RES//40))
        d.line([(TEX_RES*0.6, TEX_RES*0.35), (TEX_RES*0.7, TEX_RES*0.7)],
               fill=(60, 50, 40, 255), width=max(2, TEX_RES//40))
        return base

    def _proc_radioactive(self, col):
        base = _hex_base((70, 90, 60))
        d = ImageDraw.Draw(base)
        cx = cy = TEX_RES / 2
        rr = TEX_RES * 0.26
        c = tuple(col) + (255,)
        for k in range(3):
            a0 = math.radians(90 + k * 120 - 30)
            a1 = math.radians(90 + k * 120 + 30)
            d.pieslice([cx-rr, cy-rr, cx+rr, cy+rr],
                       math.degrees(a0), math.degrees(a1), fill=c)
        r2 = TEX_RES * 0.07
        d.ellipse([cx-r2, cy-r2, cx+r2, cy+r2], fill=(30, 30, 30, 255))
        return base


# Shared instance (built lazily so importing this module never needs a GL
# context until the renderer is actually used).
_SHARED: Optional[TileTextures] = None


def shared_textures() -> TileTextures:
    global _SHARED
    if _SHARED is None:
        _SHARED = TileTextures()
    return _SHARED


# ═══════════════════════════════════════════════════════════════════
# Board renderer
# ═══════════════════════════════════════════════════════════════════
class BoardRenderer:
    """Holds the SpriteLists for one board layout and keeps them in sync with
    the engine. Build once per layout (size/offset), then call :meth:`sync`
    whenever the engine state changes (after a move/undo/reset) — never per
    frame. :meth:`draw` issues a handful of batched GL calls.
    """

    def __init__(self, textures: Optional[TileTextures] = None):
        self.tex = textures or shared_textures()
        self.static_list = arcade.SpriteList()
        self.dynamic_list = arcade.SpriteList()
        self.box_list = arcade.SpriteList()
        self.player_list = arcade.SpriteList()
        self._dynamic_cells: dict[tuple[int, int], arcade.Sprite] = {}
        self._player_sprite: Optional[arcade.Sprite] = None
        self._cell_xy: Optional[Callable[[int, int], tuple[float, float]]] = None
        self._tile_px = 0.0
        self._piece_px = 0.0

    # ---- layout/build -----------------------------------------------------
    def build(self, engine, cell_xy: Callable[[int, int], tuple[float, float]],
              hex_size: float):
        """(Re)build all sprite lists for the current layout. Call on level
        load and whenever the window/layout changes."""
        self._cell_xy = cell_xy
        # Square sprite sized to the hex width so neighbours tile cleanly.
        self._tile_px = math.sqrt(3) * hex_size
        self._piece_px = self._tile_px * 0.82
        self.static_list = arcade.SpriteList()
        self.dynamic_list = arcade.SpriteList()
        self._dynamic_cells = {}

        for r in range(engine.rows):
            for c in range(engine.cols):
                tid = engine.grid[r][c]
                if tid == EMPTY:
                    continue
                x, y = cell_xy(r, c)
                if self.tex.is_dynamic_tile(tid):
                    spr = self._make_sprite(self.tex.get("floor"), x, y, self._tile_px)
                    self.dynamic_list.append(spr)
                    self._dynamic_cells[(r, c)] = spr
                else:
                    key = self.tex.tile_key(tid)
                    tx = self.tex.get(key) or self.tex.get("floor")
                    self.static_list.append(
                        self._make_sprite(tx, x, y, self._tile_px))

        # player sprite
        self._player_sprite = self._make_sprite(
            self.tex.get("player"), 0, 0, self._piece_px)
        self.player_list = arcade.SpriteList()
        self.player_list.append(self._player_sprite)

        self.sync(engine)

    def _make_sprite(self, texture, x, y, px) -> arcade.Sprite:
        spr = arcade.Sprite(texture)
        spr.center_x = x
        spr.center_y = y
        # scale so the texture (TEX_RES px) renders at `px` screen pixels
        spr.width = px
        spr.height = px
        return spr

    # ---- per-change sync (NOT per frame) ----------------------------------
    def sync(self, engine):
        """Update dynamic tiles, boxes and player to match engine state."""
        if self._cell_xy is None:
            return
        pressed = self._pressed_groups(engine)
        portal_active = engine.switch_on

        # dynamic tiles
        for (r, c), spr in self._dynamic_cells.items():
            tid = engine.grid[r][c]
            collected = ((r, c) in engine.collected_keys
                         or (r, c) in engine.collected_cbrn)
            laser_active = (not is_laser(tid)) or (laser_group(tid) not in pressed)
            gate_opened = (r, c) in engine.opened_gates
            slab_pressed = is_slab(tid) and slab_group(tid) in pressed
            key = self.tex.tile_key(
                tid, laser_active=laser_active, gate_opened=gate_opened,
                slab_pressed=slab_pressed, switch_on=engine.switch_on,
                portal_active=portal_active, collected=collected)
            tx = self.tex.get(key) or self.tex.get("floor")
            if spr.texture is not tx:
                spr.texture = tx
            spr.visible = (tid != EMPTY)

        # boxes — positions change, so rebuild the small list
        self.box_list = arcade.SpriteList()
        for (br, bc) in engine.boxes:
            color = engine.box_colors.get((br, bc), -1)
            key = self.tex.box_key((br, bc) in engine.targets, color)
            x, y = self._cell_xy(br, bc)
            self.box_list.append(
                self._make_sprite(self.tex.get(key), x, y, self._piece_px))

        # player
        if self._player_sprite is not None:
            on_t = (engine.player_r, engine.player_c) in engine.targets
            key = self.tex.player_key(engine.has_cbrn, on_t)
            self._player_sprite.texture = self.tex.get(key)
            x, y = self._cell_xy(engine.player_r, engine.player_c)
            self._player_sprite.center_x = x
            self._player_sprite.center_y = y

    @staticmethod
    def _pressed_groups(engine) -> set:
        """Slab groups currently pressed by a box or the player (drives laser
        and slab appearance). Mirrors the engine's own slab logic and uses its
        slab-position cache."""
        boxes = set(engine.boxes)
        player_rc = (engine.player_r, engine.player_c)
        pressed = set()
        for group, cells in getattr(engine, "_slabs_by_group", {}).items():
            for (r, c) in cells:
                if (r, c) == player_rc or (r, c) in boxes:
                    pressed.add(group)
                    break
        return pressed

    # ---- draw -------------------------------------------------------------
    def draw(self):
        """Draw the whole board in a handful of batched GL calls."""
        self.static_list.draw()
        self.dynamic_list.draw()
        self.box_list.draw()
        self.player_list.draw()
